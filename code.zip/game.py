import sys, time, random, pygame
from cv2 import GFTTDetector
from collections import deque
import cv2 as cv, mediapipe as mp

pygame.init()
     # Initialize required elements/environment
VID_CAP = cv.VideoCapture(0)
window_size = (VID_CAP.get(cv.CAP_PROP_FRAME_WIDTH), VID_CAP.get(cv.CAP_PROP_FRAME_HEIGHT)) # width by height
screen = pygame.display.set_mode(window_size)

display_width = 800
display_height = 600

#background color
light_blue=(0,230,255)

#title color
dark_blue=(0,0,54.5)

#button color
white=(255,255,255)
gray=(50.2,50.2,50.2)

 

 
gameDisplay = pygame.display.set_mode((display_width,display_height))
clock = pygame.time.Clock()
 

    # Initialize required elements/environment
VID_CAP = cv.VideoCapture(0)
window_size = (VID_CAP.get(cv.CAP_PROP_FRAME_WIDTH), VID_CAP.get(cv.CAP_PROP_FRAME_HEIGHT)) # width by height
screen = pygame.display.set_mode(window_size)


def text_objects(text, font):
    #change the color of title
    textSurface = font.render(text, True, dark_blue)
    return textSurface, textSurface.get_rect()

#x: The x location of the top left coordinate of the button box.

#y: The y location of the top left coordinate of the button box.
def button(message,x,y,width,height,function=None):
    mouse=pygame.mouse.get_pos()
        #print(mouse)
    click = pygame.mouse.get_pressed()
        #print(click)
    if x + width > mouse[0] > x and y + height > mouse[1] > y:
            pygame.draw.rect(gameDisplay,white,(x,y,width,height))
            if click[0]==1 and function != None:
                function()
                
            smallText = pygame.font.Font("freesansbold.ttf",20)
            textSurface = smallText.render(message, True, dark_blue)
            textRect=textSurface.get_rect()
            textRect.center = ((x+(width/2) ),(y+(height/2)))
            gameDisplay.blit(textSurface,textRect)
    else:
        pygame.draw.rect(gameDisplay,gray,(x,y,width,height))
        smallText = pygame.font.Font("freesansbold.ttf",20)
        textSurface = smallText.render(message, True, white)
        textRect=textSurface.get_rect()
        textRect.center = ((x+(width/2)),(y+(height/2)))
        gameDisplay.blit(textSurface,textRect)



def intro():
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()

        #pygame.transform.scale(background)
        gameDisplay.fill(light_blue)
        largeText = pygame.font.SysFont('freesansbold.ttf',50)
        TextSurf, TextRect = text_objects("Flappy Professor", largeText)
        TextRect.center = (window_size[0]/2, window_size[1]/2)
        gameDisplay.blit(TextSurf, TextRect)

       
        
        button("START",260,270,100,50,countdown)  
        button("TEST",260,350,100,50,test_finger) 
       

        


        pygame.display.update()
        clock.tick(15)
 
def countdown():
    
    window = pygame.display.set_mode((window_size[0],window_size[1]))
    clock = pygame.time.Clock()
    font = pygame.font.SysFont(None, 100)
    counter = 5
    text = font.render(str(counter), True, light_blue)
    window.fill(dark_blue)
    ready = pygame.font.SysFont('microsoftjhengheimicrosoftjhengheiuibold', 55).render('GET FINGER READY', True, light_blue)
    tr = ready.get_rect()
    tr.center = (window_size[0]/2, window_size[1]/2)
    screen.blit(ready, tr)
    pygame.display.update()
    pygame.time.wait(2000)   
    
    


   

    timer_event = pygame.USEREVENT+1
    pygame.time.set_timer(timer_event, 1000)
    clock.tick(60)        

    run = True
    while run:
        clock.tick(60)
        for event in pygame.event.get():
        
            if event.type == pygame.QUIT:
                run = False
            elif event.type == timer_event:
                counter -= 1
                text = font.render(str(counter), True, light_blue)
                if counter == 0:
                    pygame.time.set_timer(timer_event, 0)

                    game()                

        window.fill((255, 255, 255))
        text_rect = text.get_rect(center = window.get_rect().center)
        window.blit(text, text_rect)
        pygame.display.flip()
                

#maybe you want a test finger function 
def test_finger():
    mp_hands=mp.solutions.hands
    hands=mp_hands.Hands()
    mpDraw = mp.solutions.drawing_utils
    #**********************************************
    #mp_drawing = mp.solutions.drawing_utils
    #mp_drawing_styles = mp.solutions.drawing_styles
    #mp_face_mesh = mp.solutions.face_mesh
    #drawing_spec = mp_drawing.DrawingSpec(thickness=1, circle_radius=1)
    
    # Initialize required elements/environment
    #VID_CAP = cv.VideoCapture(0)
    #window_size = (VID_CAP.get(cv.CAP_PROP_FRAME_WIDTH), VID_CAP.get(cv.CAP_PROP_FRAME_HEIGHT)) # width by height
    #screen = pygame.display.set_mode(window_size)

    # Bird and pipe init
    bird_img = pygame.image.load("teacher.png")
    bird_img = pygame.transform.scale(bird_img,(bird_img.get_width() / 6, bird_img.get_height() / 6))
    bird_frame = bird_img.get_rect()
    bird_frame.center = (window_size[0] // 6, window_size[1] // 3)
    with mp_hands.Hands(
            max_num_hands=2,
            static_image_mode=False,
            min_detection_confidence=0.9,
            min_tracking_confidence=0.9) as hands:
        while True:
            # Check if game is running
               

            # Check if user quit window
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    VID_CAP.release()
                    intro()
                    #cv.destroyAllWindows()
                    #pygame.quit()
                    #sys.exit()

            # Get frame
            ret, frame =VID_CAP.read()
            #if not ret:
                #print("Empty frame, continuing...")
                #continue

            # Clear screen
            screen.fill((125, 220, 232))

            # Face mesh
            frame.flags.writeable = False

            frame = cv.cvtColor(frame, cv.COLOR_BGR2RGB)
            results = hands.process(frame)
            #results = face_mesh.process(frame)
            frame.flags.writeable = True

            # Draw mesh
            if results.multi_hand_landmarks:
                for handLms in results.multi_hand_landmarks:
                    for id,lm in enumerate(handLms.landmark):
                        h, w, c=frame.shape
                        x, y = int(lm.x * w),int(lm.y * h)
                        
            #if results.multi_hand_landmarks > 0:
            #and len(results.multi_hand_landmarks) 
                #8 = index finger
                
                    #if id == 8:
                        #cv.circle(frame, (x, y), 25, (255, 0, 255), cv.FILLED)

                mpDraw.draw_landmarks(frame, handLms, mp_hands.HAND_CONNECTIONS)

                marker = results.multi_hand_landmarks[0].landmark[8].y
                bird_frame.centery = (marker - 0.5) * 1.5 * window_size[1] + window_size[1]/2
                #if bird_frame.top < 0: bird_frame.y = 0
                #if bird_frame.bottom > window_size[1]: bird_frame.y = window_size[1] - bird_frame.height

            # Mirror frame, swap axes because opencv != pygame
            frame = cv.flip(frame, 1).swapaxes(0, 1)
            pygame.surfarray.blit_array(screen, frame)
            screen.blit(bird_img, bird_frame)
            pygame.display.flip()







def game():
    #*********************************************
    mp_hands=mp.solutions.hands
    hands=mp_hands.Hands()
    mpDraw = mp.solutions.drawing_utils
    #**********************************************
    #mp_drawing = mp.solutions.drawing_utils
    #mp_drawing_styles = mp.solutions.drawing_styles
    #mp_face_mesh = mp.solutions.face_mesh
    #drawing_spec = mp_drawing.DrawingSpec(thickness=1, circle_radius=1)
    
    # Initialize required elements/environment
    VID_CAP = cv.VideoCapture(0)
    window_size = (VID_CAP.get(cv.CAP_PROP_FRAME_WIDTH), VID_CAP.get(cv.CAP_PROP_FRAME_HEIGHT)) # width by height
    screen = pygame.display.set_mode(window_size)

    # Bird and pipe init
    bird_img = pygame.image.load("Teacher.png")
    bird_img = pygame.transform.scale(bird_img, (bird_img.get_width() / 6, bird_img.get_height() / 6))
    bird_frame = bird_img.get_rect()
    bird_frame.center = (window_size[0] // 6, window_size[1] // 2)
    pipe_frames = deque()
    pipe_img = pygame.image.load("pipe_sprite_single.png")

    pipe_starting_template = pipe_img.get_rect()
    space_between_pipes = 150

    # Game loop
    game_clock = time.time()
    stage = 1
    pipeSpawnTimer = 0
    time_between_pipe_spawn = 40
    dist_between_pipes = 500
    pipe_velocity = lambda: dist_between_pipes / time_between_pipe_spawn
    level = 0
    score = 0
    didUpdateScore = False
    game_is_running = True

    with mp_hands.Hands(
            max_num_hands=2,
            static_image_mode=True,
            min_detection_confidence=0.7,
            min_tracking_confidence=0.9) as hands:
        while True:
            # Check if game is running
            if not game_is_running:
                text = pygame.font.SysFont('microsoftjhengheimicrosoftjhengheiuibold', 80).render('Game Over!!', True, (255, 0, 0))
                tr = text.get_rect()
                tr.center = (window_size[0]/2, window_size[1]/2)
                screen.blit(text, tr)
                pygame.display.update()
                pygame.time.wait(2000)
                VID_CAP.release()
                outro(score,stage)
                cv.destroyAllWindows()
                pygame.quit()
                sys.exit()

            # Check if user quit window
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    VID_CAP.release()
                    cv.destroyAllWindows()
                    pygame.quit()
                    sys.exit()

            # Get frame
            ret, frame =VID_CAP.read()
            if not ret:
                print("Empty frame, continuing...")
                continue

            # Clear screen
            screen.fill((125, 220, 232))

            # Face mesh
            frame.flags.writeable = False

            frame = cv.cvtColor(frame, cv.COLOR_BGR2RGB)
            results = hands.process(frame)
            #results = face_mesh.process(frame)
            frame.flags.writeable = True

            # Draw mesh
            if results.multi_hand_landmarks:
                for handLms in results.multi_hand_landmarks:
                    for id,lm in enumerate(handLms.landmark):
                        h, w, c=frame.shape
                        x, y = int(lm.x * w),int(lm.y * h)
                        
            #if results.multi_hand_landmarks > 0:
            #and len(results.multi_hand_landmarks) 
                #8 = index finger
                marker = results.multi_hand_landmarks[0].landmark[8].y
                bird_frame.centery = (marker - 0.5) * 1.5 * window_size[1] + window_size[1]/2
                if bird_frame.top < 0: bird_frame.y = 0
                if bird_frame.bottom > window_size[1]: bird_frame.y = window_size[1] - bird_frame.height

            # Mirror frame, swap axes because opencv != pygame
            frame = cv.flip(frame, 1).swapaxes(0, 1)

            # Update pipe positions
            for pf in pipe_frames:
                pf[0].x -= pipe_velocity()
                pf[1].x -= pipe_velocity()

            if len(pipe_frames) > 0 and pipe_frames[0][0].right < 0:
                pipe_frames.popleft()

            # Update screen
            pygame.surfarray.blit_array(screen, frame)
            screen.blit(bird_img, bird_frame)
            checker = True
            for pf in pipe_frames:
                # Check if bird went through to update score
                if pf[0].left <= bird_frame.x <= pf[0].right:
                    checker = False
                    if not didUpdateScore:
                        score += 1
                        didUpdateScore = True
                # Update screen
                screen.blit(pipe_img, pf[1])
                screen.blit(pygame.transform.flip(pipe_img, 0, 1), pf[0])
            if checker: didUpdateScore = False

            # Stage, score text
            text = pygame.font.SysFont("Helvetica Bold.ttf", 50).render(f'Stage {stage}', True, (99, 245, 255))
            tr = text.get_rect()
            tr.center = (100, 50)
            screen.blit(text, tr)
            text = pygame.font.SysFont("Helvetica Bold.ttf", 50).render(f'Score: {score}', True, (99, 245, 255))
            tr = text.get_rect()
            tr.center = (100, 100)
            screen.blit(text, tr)

            # Update screen
            pygame.display.flip()

            # Check if bird is touching a pipe
            if any([bird_frame.colliderect(pf[0]) or bird_frame.colliderect(pf[1]) for pf in pipe_frames]):
                game_is_running = False
                
                

            # Time to add new pipes
            if pipeSpawnTimer == 0:
                top = pipe_starting_template.copy()
                top.x, top.y = window_size[0], random.randint(120 - 1000, window_size[1] - 120 - space_between_pipes - 1000)
                
                bottom = pipe_starting_template.copy()
                bottom.x, bottom.y = window_size[0], top.y + 1000 + space_between_pipes
                pipe_frames.append([top, bottom])

            # Update pipe spawn timer - make it cyclical
            pipeSpawnTimer += 1
            if pipeSpawnTimer >= time_between_pipe_spawn: pipeSpawnTimer = 0

            # Update stage
            if time.time() - game_clock >= 10:
                time_between_pipe_spawn *= 5 / 6
                stage += 1
                game_clock = time.time()

def outro(score,stage):
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()

        #pygame.transform.scale(background)
        gameDisplay.fill(light_blue)
        largeText = pygame.font.SysFont('freesansbold.ttf',50)
        TextSurf, TextRect = text_objects("YOU LOSE", largeText)
        TextRect.center = (window_size[0]/2, window_size[1]/2)
        gameDisplay.blit(TextSurf, TextRect)
        text = pygame.font.SysFont("Helvetica Bold.ttf", 50).render(f'Final Stage: {stage}', True, dark_blue)
        tr = text.get_rect()
        tr.center = (320,120)
        screen.blit(text, tr)
        text = pygame.font.SysFont("Helvetica Bold.ttf", 50).render(f'Final Score: {score}', True, dark_blue)
        tr = text.get_rect()
        tr.center = (320, 160)
        screen.blit(text, tr)
       

       
        
        button("PLAY AGAIN?",230,270,180,50,countdown)  
        button("TEST",270,330,100,50,test_finger) 
       

        


        pygame.display.update()
        clock.tick(15)

intro()
